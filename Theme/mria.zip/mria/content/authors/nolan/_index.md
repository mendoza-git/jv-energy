---
name: Nolan Bergson
image: 'https://via.placeholder.com/400x400'
cover: 'https://via.placeholder.com/1920x1080'
location: New York
website: https://www.google.com
twitter: https://twitter.com
facebook: https://www.facebook.com
---
I can and will deliver great results with a process that’s timely, collaborative and at a great value for my clients.